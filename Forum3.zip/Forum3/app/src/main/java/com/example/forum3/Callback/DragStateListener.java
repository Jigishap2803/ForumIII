package com.example.forum3.Callback;

public interface DragStateListener {
    void onDragStart();

    void onDragEnd(boolean isMenuOpened);
}
