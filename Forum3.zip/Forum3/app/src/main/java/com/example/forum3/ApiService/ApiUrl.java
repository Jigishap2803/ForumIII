package com.example.forum3.ApiService;

public interface ApiUrl {
    //String BASE_URL = "https://runtimeeventapp.com/hforlife/webservices.php/";

//     String BASE_URL = "http://219.90.67.58/forum-3/webservices.php/";


     String BASE_URL = "http://182.18.138.199/forum-3/webservices.php/";

     // reqAction=signup&name=Asish Goyal&gender=Male&mobile=9899999999&email_id=asish@gmail.com&address=flat no 6 Mumbai&password=123456&ip_address=158.58.10.20
}
