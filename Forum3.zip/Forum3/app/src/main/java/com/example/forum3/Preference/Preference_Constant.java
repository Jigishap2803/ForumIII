package com.example.forum3.Preference;

public class Preference_Constant {
    public static final String USER_ID = "user_id";
    public static final String COMPANY_DATA = "company_data";
    public static final String COMPANY_POS = "company_pos";
    public static final String login_id = "login_id";
    public static final String IS_LOGGED_IN = "logged_in";
}
