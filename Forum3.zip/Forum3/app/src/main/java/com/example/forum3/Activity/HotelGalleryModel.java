package com.example.forum3.Activity;

public class HotelGalleryModel {
    private Integer gallery_pic;

    public HotelGalleryModel(int gallery_pic) {
        this.gallery_pic = gallery_pic;
    }

    public int getGallery_pic() {
        return gallery_pic;
    }

    public void setGallery_pic(int gallery_pic) {
        this.gallery_pic = gallery_pic;
    }
}
