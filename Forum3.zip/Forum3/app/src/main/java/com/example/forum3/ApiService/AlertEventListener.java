package com.example.forum3.ApiService;

public interface AlertEventListener {
    void didSelectListItem(int var1, String var2, String var3);
}
