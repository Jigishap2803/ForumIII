package com.example.forum3.Transform;

import android.view.View;

public interface RootTransformation {
    void transform(float dragProgress, View rootView);
}
