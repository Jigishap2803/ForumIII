package com.example.forum3.Callback;

public interface DragListener {
    void onDrag(float progress);
}
