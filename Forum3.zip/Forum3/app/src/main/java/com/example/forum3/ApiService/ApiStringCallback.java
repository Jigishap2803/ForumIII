package com.example.forum3.ApiService;

public interface ApiStringCallback {
    void onResponse(String var1, int var2);

    void onFailure(Throwable var1, int var2);
}
